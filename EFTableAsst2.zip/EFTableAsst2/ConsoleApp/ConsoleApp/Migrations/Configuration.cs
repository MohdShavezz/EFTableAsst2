﻿namespace ConsoleApp.Migrations
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<ConsoleApp.EmpContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(ConsoleApp.EmpContext context)
        {
            if (!context.Employees.Any())
            {
                List<Employee> employees = new List<Employee>
                {
                    new Employee
                    {
                        Name = "Nidhi",
                        Age = 21,
                        Skills = "Java",
                        Company = "Aspirefox"
                    },
                    new Employee { Name = "Rohit", Age = 22, Skills = "Java,Asp.Net", Company = "TCS" },
                    new Employee { Name = "Aarchi", Age = 22, Skills = "Asp.Net", Company = "TCS" },
                    new Employee { Name = "John", Age = 30, Skills = "C#", Company = "Microsoft" },
                    new Employee { Name = "Jane", Age = 25, Skills = "JavaScript", Company = "Google" },
                    new Employee { Name = "Mark", Age = 28, Skills = "Python", Company = "Amazon" },
                    new Employee { Name = "Emily", Age = 35, Skills = "Java", Company = "Oracle" },
                    new Employee { Name = "William", Age = 40, Skills = "C++,Python", Company = "Intel" },
                    new Employee { Name = "Sophia", Age = 26, Skills = "Java,Python", Company = "IBM" },
                    new Employee { Name = "David", Age = 32, Skills = "JavaScript,PHP", Company = "Facebook" },
                    new Employee { Name = "Sarah", Age = 27, Skills = "C++,Objective-C", Company = "Apple" },
                    new Employee { Name = "Jacob", Age = 29, Skills = "Swift,Objective-C", Company = "Apple" },
                    new Employee { Name = "Olivia", Age = 23, Skills = "HTML,CSS", Company = "Google" },
                    new Employee { Name = "Noah", Age = 31, Skills = "Python,Java", Company = "Amazon" },
                    new Employee { Name = "Isabella", Age = 24, Skills = "JavaScript,PHP", Company = "Facebook" },
                    new Employee { Name = "Liam", Age = 26, Skills = "Python,Java", Company = "Microsoft" },
                    new Employee { Name = "Ava", Age = 29, Skills = "HTML,CSS", Company = "Twitter" },
                    new Employee { Name = "Michael", Age = 36, Skills = "Java", Company = "Intel" },
                    new Employee { Name = "Mia", Age = 33, Skills = "C++,Python", Company = "IBM" },
                    new Employee { Name = "Ethan", Age = 28, Skills = "Swift,Objective-C", Company = "Apple" },
                    new Employee { Name = "Emma", Age = 25, Skills = "JavaScript", Company = "Google" },
                    new Employee { Name = "Alexander", Age = 30, Skills = "C#", Company = "Microsoft" },
                    new Employee { Name = "Sofia", Age = 27, Skills = "Java", Company = "Oracle" },
                    new Employee { Name = "Liam", Age = 25, Skills = "C#,Python", Company = "Microsoft" },
                    new Employee { Name = "Ava", Age = 30, Skills = "JavaScript,HTML", Company = "Twitter" },
                    new Employee { Name = "James", Age = 34, Skills = "Java,Python", Company = "IBM" },
                    new Employee { Name = "Evelyn", Age = 28, Skills = "C++,Java", Company = "Intel" },
                    new Employee { Name = "Lucas", Age = 27, Skills = "Swift,Objective-C", Company = "Apple" },
                    new Employee { Name = "Harper", Age = 26, Skills = "JavaScript,PHP", Company = "Facebook" },
                    new Employee { Name = "Mason", Age = 33, Skills = "C++,Python", Company = "IBM" },
                    new Employee { Name = "Madison", Age = 23, Skills = "HTML,CSS", Company = "Google" },
                    new Employee { Name = "Logan", Age = 29, Skills = "Java,Python", Company = "Amazon" },
                    new Employee { Name = "Avery", Age = 24, Skills = "JavaScript,HTML", Company = "Twitter" },
                    new Employee { Name = "Alexander", Age = 31, Skills = "C#,Python", Company = "Microsoft" },
                    new Employee { Name = "Lily", Age = 26, Skills = "Java,Python", Company = "Amazon" },
                    new Employee { Name = "Carter", Age = 32, Skills = "C++,Java", Company = "Intel" },
                    new Employee { Name = "Chloe", Age = 27, Skills = "JavaScript", Company = "Google" },
                    new Employee { Name = "Jacob", Age = 30, Skills = "Python,Java", Company = "Amazon" },
                    new Employee { Name = "Grace", Age = 25, Skills = "HTML,CSS", Company = "Google" },
                    new Employee { Name = "Owen", Age = 28, Skills = "Swift,Objective-C", Company = "Apple" },
                    new Employee { Name = "Emma", Age = 29, Skills = "Java", Company = "Oracle" },
                    new Employee { Name = "Wyatt", Age = 31, Skills = "C++,Python", Company = "IBM" },
                    new Employee { Name = "Aria", Age = 26, Skills = "JavaScript,PHP", Company = "Facebook" },
                    new Employee { Name = "Jack", Age = 34, Skills = "Java,Python", Company = "Amazon" },
                    new Employee { Name = "Mila", Age = 27, Skills = "HTML,CSS", Company = "Google" },
                    new Employee { Name = "Luke", Age = 30, Skills = "C#,Python", Company = "Microsoft" },
                    new Employee { Name = "Nora", Age = 24, Skills = "JavaScript,HTML", Company = "Twitter" },
                    new Employee { Name = "Oliver", Age = 33, Skills = "Python,Java", Company = "Amazon" },
                    new Employee { Name = "Aaliyah", Age = 28, Skills = "Java,Python", Company = "IBM" },
                    new Employee { Name = "Benjamin", Age = 32, Skills = "Python,JavaScript", Company = "Amazon" },
                    new Employee { Name = "Charlotte", Age = 26, Skills = "HTML,CSS", Company = "Google" },
                    new Employee { Name = "William", Age = 38, Skills = "C++,Java", Company = "Intel" }
                };
                context.Employees.AddRange(employees);
                context.SaveChanges();
            }
        }
    }
}
