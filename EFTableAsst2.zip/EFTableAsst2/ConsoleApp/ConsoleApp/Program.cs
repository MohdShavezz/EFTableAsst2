﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Actions Act = new Actions();
                while (true)
                {
                    bool Quit = false;
                    Console.WriteLine("\n-------------------------------------------------------");
                    Console.WriteLine("1.Show Records based on input page Number and page Length");
                    Console.WriteLine("2.Show Records based on Input text");
                    Console.WriteLine("3.Sort & Display List Based on Column");
                    Console.WriteLine("4.Show all Records");
                    Console.WriteLine("5.Quit Application");
                    Console.WriteLine("---------------------------------------------------------");
                    Console.WriteLine("\nEnter Choice:");


                    int Choice = int.Parse(Console.ReadLine());
                    switch (Choice)
                    {
                        case 1:
                            Act.ShowByPageNumberAndLength();
                            break;
                        case 2:
                            Act.ShowAllInputText();
                            break;
                        case 3:
                            Act.SortRecords();
                            break;
                        case 4:
                            Act.ShowAllRecords();
                            break;
                        case 5:
                            Quit = true;
                            break;

                        default:
                            Console.WriteLine("Invalid Input!!!");
                            break;

                    }
                    if (Quit)
                    {
                        break;
                    }
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine("Error: " + Ex.Message);
                Console.ReadLine();
            }

        }
    }
}
