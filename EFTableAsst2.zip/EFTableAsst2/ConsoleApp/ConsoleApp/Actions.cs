﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Actions
    {
        public EmpContext ctx;
        public Actions()
        {
            ctx = new EmpContext();
        }

        public void ShowByPageNumberAndLength()
        {
            try
            {
                Console.WriteLine("Enter Page no:");
                int PageNo = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Length:");
                int Lengh = int.Parse(Console.ReadLine());
                List<Employee> EmpList = null;
                EmpList = ctx.Employees.OrderBy(e => e.Id).Skip((PageNo - 1) * Lengh).Take(Lengh).ToList();

                if (EmpList.Count > 0)
                {
                    Console.WriteLine("\nID\tName\tAge\tSkills\tCompany");
                    foreach (var i in EmpList)
                    {
                        Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", i.Id, i.Name, i.Age, i.Skills, i.Company);
                    }
                }
                else
                {
                    Console.WriteLine("Not found.");
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

        }
        public void ShowAllInputText()
        {
            Console.WriteLine("Search Text:");
            string Text = Console.ReadLine();
            List<Employee> EmpList = null;
            EmpList = ctx.Employees.Where(e => e.Id.ToString().Contains(Text)
                || e.Name.Contains(Text)
                || e.Age.ToString().Contains(Text)
                || e.Skills.Contains(Text)
                || e.Company.Contains(Text)).ToList();

            if (EmpList.Count > 0)
            {
                Console.WriteLine("\nID\tName\tAge\tSkills\tCompany");
                foreach (var i in EmpList)
                {
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", i.Id, i.Name, i.Age, i.Skills, i.Company);
                }
            }
            else
            {
                Console.WriteLine("Not found.");
            }
        }
        public void ShowAllRecords()
        {
            List<Employee> EmpList = null;
            EmpList = ctx.Employees.ToList();

            if (EmpList != null)
            {
                Console.WriteLine("\nID\tName\tAge\tSkills\tCompany");
                Console.WriteLine("-----------------------------------------------------");
                foreach (var i in EmpList)
                {
                    Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", i.Id, i.Name, i.Age, i.Skills, i.Company);
                }
            }
            else
            {
                Console.WriteLine("Not found.");
            }
        }
        public void SortRecords()
        {
            List<Employee> EmpList = null;
            EmpList = ctx.Employees.ToList();
            try
            {
                while (true)
                {
                    bool Done = false;
                    Console.WriteLine("\n1.Sort by EmployeeId");
                    Console.WriteLine("2.Sort by EmployeeName");
                    Console.WriteLine("3.Sort by EmployeeAge");
                    Console.WriteLine("4.Sort by EmployeeSkills");
                    Console.WriteLine("5.Sort by EmployeeCompany");
                    Console.WriteLine("6.Exit");
                    Console.WriteLine("Enter Choice:");
                    int Choice = int.Parse(Console.ReadLine());

                    switch (Choice)
                    {
                        case 1:
                            EmpList = EmpList.OrderBy(e => e.Id).ToList();
                            Done = true;
                            break;
                        case 2:
                            EmpList = EmpList.OrderBy(e => e.Name).ToList();
                            Done = true;
                            break;
                        case 3:
                            EmpList = EmpList.OrderBy(e => e.Age).ToList();
                            Done = true;
                            break;
                        case 4:
                            EmpList = EmpList.OrderBy(e => e.Skills).ToList();
                            Done = true;
                            break;
                        case 5:
                            EmpList = EmpList.OrderBy(e => e.Company).ToList();
                            Done = true;
                            break;
                        case 6:
                            Done = false;
                            break;
                        default:
                            Console.WriteLine("Invalid Input.");
                            break;
                    }
                    if (Done)
                    {

                        Console.WriteLine("Sorted Successfully!!! Wanna See Sorted Records (y/n):");
                        string WannaShow = Console.ReadLine();
                        if (WannaShow == "y")
                        {
                            if (EmpList != null)
                            {
                                try
                                {
                                    Console.WriteLine("Enter Page no:");
                                    int PageNo = int.Parse(Console.ReadLine());
                                    Console.WriteLine("Enter Length:");
                                    int Lengh = int.Parse(Console.ReadLine());
                                    EmpList = EmpList.Skip((PageNo - 1) * Lengh).Take(Lengh).ToList();
                                    if (EmpList.Count > 0)
                                    {
                                        Console.WriteLine("\nID\tName\tAge\tSkills\tCompany");
                                        Console.WriteLine("-----------------------------------------------------");
                                        foreach (var i in EmpList)
                                        {
                                            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", i.Id, i.Name, i.Age, i.Skills, i.Company);
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Not found.");
                                    }
                                }
                                catch (Exception Ex)
                                {
                                    Console.WriteLine(Ex.Message);
                                }

                            }
                            else
                            {
                                Console.WriteLine("Not found.");
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }

        }

    }
}
