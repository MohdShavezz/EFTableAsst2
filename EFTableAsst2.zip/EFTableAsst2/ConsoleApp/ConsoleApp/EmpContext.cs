﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class EmpContext : DbContext
    {
        public EmpContext() : base("EmpContext")
        { }

        public DbSet<Employee> Employees { get; set; }
    }
}
